# RDWO Website

This is a simple website created for showcasing information about the RDWO cryptocurrency project.

## Usage

To view the website locally, open the `index.html` file in your web browser.

## Contributing

Contributions are not accepted for this project as it's a static website.

## License

This project is licensed under the [MIT License](LICENSE.md).

---

**Note:** This is not my own project; it was created for someone who requested this page.

Created by [PRAS Samin](https://github.com/PRASSamin).  
Repository: [PRASSamin/Private-Projects](https://github.com/PRASSamin/Private-Projects)
